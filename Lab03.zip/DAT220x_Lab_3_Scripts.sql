/* Exercise 3 */
IF OBJECT_ID('dbo.Orders','U') IS NOT NULL DROP TABLE dbo.Orders;
CREATE TABLE [dbo].[Orders]
(
	[OrderID] [int] NOT NULL,
	[CustomerID] [int] NOT NULL,
	[OrderDate] [date] NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
GO


----------------------

SELECT * FROM Orders



/* Exercise 4 */
SELECT * FROM Orders


/* Exercise 5 */
CREATE MASTER KEY;

CREATE DATABASE SCOPED CREDENTIAL LabStorageCredential WITH IDENTITY = 'user',
SECRET = '<StorageAccountKey1>';

CREATE EXTERNAL DATA SOURCE LabStorage WITH (
TYPE = HADOOP,
LOCATION =
'wasbs://<StorageContainer>@<StorageAccount>.blob.core.windows.net', CREDENTIAL = LabStorageCredential
);

CREATE EXTERNAL FILE FORMAT TextFile WITH (
FORMAT_TYPE = DelimitedText, FORMAT_OPTIONS (FIELD_TERMINATOR = ',')
);


--------------------------


CREATE EXTERNAL TABLE dbo.BeachSensorsExternal ( 
	StationName VARCHAR(50) NOT NULL, 
	MeasurementTimestamp VARCHAR(50) NOT NULL, 
	AirTemperature DECIMAL(9,2) NULL, 
	WetBulbTemperature DECIMAL(9,2) NULL,
	Humidity DECIMAL(9,2) NULL,
	RainIntensity DECIMAL(9,2) NULL, 
	IntervalRain DECIMAL(9,2) NULL, 
	TotalRain DECIMAL(9,2) NULL,
	PrecipitationType DECIMAL(9,2) NULL, 
	WindDirection DECIMAL(9,2) NULL, 
	WindSpeed DECIMAL(9,2) NULL,
	MaximumWindSpeed DECIMAL(9,2) NULL, 
	BarometricPressure DECIMAL(9,2) NULL, 
	SolarRadiation DECIMAL(9,2) NULL, 
	Heading DECIMAL(9,2) NULL,
	BatteryLife DECIMAL(9,2) NULL, 
	MeasurementTimestampLabel VARCHAR(50) NOT NULL, 
	MeasurementID VARCHAR(100) NOT NULL
)
WITH (
	LOCATION='/',
	DATA_SOURCE=LabStorage, FILE_FORMAT=TextFile
);

----------------------


CREATE TABLE [dbo].[BeachSensor]
WITH (
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX 
	
) AS
SELECT
	StationName,
	CAST(MeasurementTimestamp as DATETIME) AS MeasurementDateTime, 
	AirTemperature,
	WetBulbTemperature, 
	Humidity, 
	RainIntensity, 
	IntervalRain, 
	TotalRain, 
	PrecipitationType, 
	WindDirection, 
	WindSpeed, 
	MaximumWindSpeed, 
	BarometricPressure, 
	SolarRadiation, 
	Heading, 
	BatteryLife
FROM dbo.BeachSensorsExternal;

SELECT COUNT(*) FROM dbo.BeachSensor;


/*********************************
CLEANUP
*********************************/

/* Exercise 3 */
DROP TABLE Orders;


/* Exercise 5 */
DROP EXTERNAL TABLE BeachSensorsExternal;
DROP TABLE BeachSensor;

DROP EXTERNAL FILE FORMAT TextFile;
DROP EXTERNAL DATA SOURCE LabStorage;
DROP DATABASE SCOPED CREDENTIAL LabStorageCredential;
DROP MASTER KEY;

